Fixes # .

Changes Proposed in this Pull Request:

- foo
- bar
- baz

I have written tests for:

[](Remove the `[]()` to uncomment the appropriate lines)

[](- New features introduced)
[](- Bugs fixed)
[](- Neither (I'm just enhancing tests!))
