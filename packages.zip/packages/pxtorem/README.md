# [pxtorem](https://atom.io/packages/pxtorem)  [![License](https://img.shields.io/apm/l/atom-clock.svg?style=flat-square)](https://github.com/w3cay/pxtorem/LICENSE.md)

A package that turn your pixels text into rem. origin from [px2rem](https://github.com/shunjinchan/px2rem)

![A screenshot of your package](https://raw.githubusercontent.com/w3cay/pxtorem/v0.0.0/pxtorem.gif)

## Install
 With apm:
```bash
apm install pxtorem
```
Or Settingss ➔ Packages ➔ Search for `pxtorem`

## Options
`addMark:true` Add origin pixel value like /* 100/75 */

`baseSize:75` This will change the base size to convert px to rem

`Precision:2` The number of digits to the right of the decimal point
