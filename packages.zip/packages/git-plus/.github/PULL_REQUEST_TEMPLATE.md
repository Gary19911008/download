Have you looked at the [guidelines](https://github.com/akonwi/git-plus/blob/master/.github/CONTRIBUTING.md) for contributing to this codebase?
Have you added tests and run `apm test`?
